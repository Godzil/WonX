/*****************************************************************************/
/* Character class for WonderWitch                                           */
/* ����饯�����ʤɤΥ��ץ饤�Ȳ����򰷤����饹                              */
/*                                                                           */
/* WonderWitch �Ρ֥��ץ饤�ȡפϡ�"Character" �ȸƤ֤Τ����ա�              */
/* WonderWitch �Ρ֥���饯���פϡ�"Picture" �ȸƤ֤Τ����ա�                */
/*****************************************************************************/

#include "charap.h"

#include "etc.h"

int Character_GetX(Character character) { return (character->x); }
int Character_GetY(Character character) { return (character->y); }
Picture Character_GetPicture(Character character)
{ return (character->picture); }

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥ�����                                                        */
/*---------------------------------------------------------------------------*/

Character Character_Create(Character character, Disp disp, Picture picture,
			   int x, int y)
{
  unsigned short int char_data = 0x0000;

  if (character == NULL) Error("Character_Create", "Cannot allocate memory.");

  character->disp = disp;
  character->picture = picture;
  character->number = Disp_GetSpriteNumber(disp);
  character->x = x;
  character->y = y;

  /* ����饯���ֹ����� */
  char_data |=
    ((unsigned short int)Picture_GetNumber(character->picture)) & 0x01ff;

  /* ����饯���ѥ�å��ֹ� */
  char_data &= ~((0x0001 << 9) | (0x0001 << 10) | (0x0001 << 11));

  char_data &= ~(0x0001 << 12); /* ����åԥ󥰥����� */

  /* �����꡼�󣲤��Ф���ͥ���١�1�ǥ����꡼�󣲤��ͥ�补 */
  char_data &= ~(0x0001 << 13); /* ������֤Ǥ���ɽ�� */

  char_data &= ~(0x0001 << 14); /* ������ȿžɽ�����ʤ� */
  char_data &= ~(0x0001 << 15); /* ������ȿžɽ�����ʤ� */

  character->char_data = char_data;

  sprite_set_char(character->number, character->char_data);
  sprite_set_location(character->number, character->x, character->y);

  Character_Hide(character);

  return (character);
}

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥκ��                                                        */
/*---------------------------------------------------------------------------*/

Character Character_Destroy(Character character)
{
  Character_Hide(character);

  /* ���ץ饤���ֹ�� Disp ���֥������Ȥ��֤��� */
  Disp_ReturnSpriteNumber(character->disp, character->number);

  return (NULL);
}

/*---------------------------------------------------------------------------*/
/* ����                                                                      */
/*---------------------------------------------------------------------------*/

int Character_Locate(Character character, int x, int y)
{
  int w, h;

  character->x = x;
  character->y = y;

  x = character->x * DISP_PICTURE_TICS_X - Disp_GetRollX(character->disp);
  y = character->y * DISP_PICTURE_TICS_Y - Disp_GetRollY(character->disp);

  w = Picture_GetWidth(character->picture);
  h = Picture_GetHeight(character->picture);

  if ( (x <= DISP_GAME_X - w) ||
       (y <= DISP_GAME_Y - h) ||
       (x >= DISP_GAME_X + DISP_GAME_WIDTH) ||
       (y >= DISP_GAME_Y + DISP_GAME_HEIGHT) ) {
    x = 0;
    y = DISP_DISPLAY_HEIGHT;
  }

  sprite_set_location(character->number, x, y);

  return (0);
}

/*---------------------------------------------------------------------------*/
/* ��ư                                                                      */
/*---------------------------------------------------------------------------*/

int Character_Move(Character character, int delta_x, int delta_y)
{
  int x, y;

  x = character->x + delta_x;
  y = character->y + delta_y;
  Character_Locate(character, x, y);

  return (0);
}

/*---------------------------------------------------------------------------*/
/* �Ļ���֤ˤ���                                                            */
/*---------------------------------------------------------------------------*/

int Character_Visible(Character character)
{
  /* �����꡼�󣲤��Ф���ͥ���١�1�ǥ����꡼�󣲤��ͥ�补 */
  character->char_data |=  (0x0001 << 13);
  sprite_set_char(character->number, character->char_data);
  return (1);
}

/*---------------------------------------------------------------------------*/
/* ��ɽ�����֤ˤ���                                                          */
/*---------------------------------------------------------------------------*/

int Character_Hide(Character character)
{
  /* �����꡼�󣲤��Ф���ͥ���١�1�ǥ����꡼�󣲤��ͥ�补 */
  character->char_data &= ~(0x0001 << 13);
  sprite_set_char(character->number, character->char_data);
  return (0);
}

/*---------------------------------------------------------------------------*/
/* ���������ꤹ��                                                            */
/*---------------------------------------------------------------------------*/

int Character_SetPicture(Character character, Picture picture)
{
  character->picture = picture;
  /* ����饯���ֹ����� */
  character->char_data &= ~0x01ff;
  character->char_data |=
    ((unsigned short int)Picture_GetNumber(character->picture)) & 0x01ff;
  sprite_set_char(character->number, character->char_data);
  return (0);
}

/*---------------------------------------------------------------------------*/
/* ���ꤷ������饯������̤�����ˤ�äƤ���                                */
/*---------------------------------------------------------------------------*/

int Character_PutCharacterAtCenterOfScreen(Character character)
{
  int x, y;

  x = character->x * DISP_PICTURE_TICS_X +
    Picture_GetWidth( character->picture) / 2;
  y = character->y * DISP_PICTURE_TICS_Y +
    Picture_GetHeight(character->picture) / 2;

  return (Disp_PutPointAtCenterOfScreen(character->disp, x, y));
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
