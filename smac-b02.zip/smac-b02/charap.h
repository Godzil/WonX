/*****************************************************************************/
/* Character class for WonderWitch                                           */
/* ����饯�����򰷤����饹                                                  */
/* WonderWitch �Ρ֥��ץ饤�ȡפϡ�"Character" �ȸƤ֤Τ����ա�              */
/* WonderWitch �Ρ֥���饯���פϡ�"Picture" �ȸƤ֤Τ����ա�                */
/*****************************************************************************/

#ifndef _CharacterP_h_INCLUDED_
#define _CharacterP_h_INCLUDED_

#include "chara.h"

typedef struct _Character {
  Disp disp;
  Picture picture;
  int number; /* ���ץ饤���ֹ� */
  int x, y; /* ��ɸ */
  unsigned short int char_data;
} _Character;

#endif /* _CharacterP_h_INCLUDED_ */

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
