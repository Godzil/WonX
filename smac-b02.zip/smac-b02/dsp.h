/*****************************************************************************/
/* Disp for WonderWitch                                                      */
/* �ǥ����ץ쥤��Ϣ�򰷤����饹                                              */
/*****************************************************************************/

#ifndef _Disp_h_INCLUDED_
#define _Disp_h_INCLUDED_

typedef struct _Disp * Disp;

#include <stdio.h>
#include <sys/disp.h>
#include <sys/key.h>

#define DISP_DISPLAY_WIDTH  LCD_PIXEL_WIDTH
#define DISP_DISPLAY_HEIGHT LCD_PIXEL_HEIGHT
#define DISP_PICTURE_TICS_X 8
#define DISP_PICTURE_TICS_Y 8

#define DISP_BAR_WIDTH  DISP_DISPLAY_WIDTH
#define DISP_BAR_HEIGHT DISP_PICTURE_TICS_Y

#define DISP_GAME_WIDTH  DISP_DISPLAY_WIDTH
#define DISP_GAME_HEIGHT (DISP_DISPLAY_HEIGHT - DISP_BAR_HEIGHT)

#define DISP_GAME_X 0
#define DISP_GAME_Y 0

#define DISP_BAR_X 0
#define DISP_BAR_Y (DISP_GAME_Y + DISP_GAME_HEIGHT)

#define DISP_BAR_CHARACTER_X (DISP_BAR_X / DISP_PICTURE_TICS_X)
#define DISP_BAR_CHARACTER_Y (DISP_BAR_Y / DISP_PICTURE_TICS_Y)
#define DISP_BAR_CHARACTER_WIDTH  (DISP_BAR_WIDTH  / DISP_PICTURE_TICS_X)
#define DISP_BAR_CHARACTER_HEIGHT (DISP_BAR_HEIGHT / DISP_PICTURE_TICS_Y)

#define DISP_GAME_CHARACTER_X (DISP_GAME_X / DISP_PICTURE_TICS_X)
#define DISP_GAME_CHARACTER_Y (DISP_GAME_Y / DISP_PICTURE_TICS_Y)
#define DISP_GAME_CHARACTER_WIDTH  (DISP_GAME_WIDTH  / DISP_PICTURE_TICS_X)
#define DISP_GAME_CHARACTER_HEIGHT (DISP_GAME_HEIGHT / DISP_PICTURE_TICS_Y)

#define DISP_TEXT_X 0
#define DISP_TEXT_Y 0
#define DISP_TEXT_WIDTH  TEXT_SCREEN_WIDTH
#define DISP_TEXT_HEIGHT TEXT_SCREEN_HEIGHT

#define DISP_SCREEN_WIDTH  SCREEN_PIXEL_WIDTH
#define DISP_SCREEN_HEIGHT SCREEN_PIXEL_HEIGHT

#define DISP_SCREEN_CHARACTER_WIDTH  SCREEN_CHAR_WIDTH
#define DISP_SCREEN_CHARACTER_HEIGHT SCREEN_CHAR_HEIGHT

#define DISP_BUTTON_START KEY_START
#define DISP_BUTTON_A     KEY_A
#define DISP_BUTTON_B     KEY_B
#define DISP_BUTTON_UP    KEY_UP1
#define DISP_BUTTON_RIGHT KEY_RIGHT1
#define DISP_BUTTON_DOWN  KEY_DOWN1
#define DISP_BUTTON_LEFT  KEY_LEFT1

int Disp_GetRollX(Disp disp);
int Disp_GetRollY(Disp disp);

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥκ���                                                        */
/*---------------------------------------------------------------------------*/

Disp Disp_Create(Disp disp);

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥκ��                                                        */
/*---------------------------------------------------------------------------*/

Disp Disp_Destroy(Disp disp);

/*---------------------------------------------------------------------------*/
/* ���Ѳ�ǽ�ʥ��ץ饤���ֹ���������                                        */
/*---------------------------------------------------------------------------*/

int Disp_GetSpriteNumber(Disp disp);

/*---------------------------------------------------------------------------*/
/* ���ץ饤���ֹ���ֵѤ���                                                  */
/*---------------------------------------------------------------------------*/

int Disp_ReturnSpriteNumber(Disp disp, int number);

/*---------------------------------------------------------------------------*/
/* ���Ѳ�ǽ�ʥ���饯�����ֹ���������                                      */
/*---------------------------------------------------------------------------*/

int Disp_GetCharacterNumber(Disp disp);

/*---------------------------------------------------------------------------*/
/* ����饯�����ֹ���ֵѤ���                                                */
/*---------------------------------------------------------------------------*/

int Disp_ReturnCharacterNumber(Disp disp, int number);

/*---------------------------------------------------------------------------*/
/* ��������                                                                  */
/*---------------------------------------------------------------------------*/

int Disp_GetButtonStatus(Disp disp);

/*---------------------------------------------------------------------------*/
/* ���ꤷ����ɸ����̤�����ˤ�äƤ���                                      */
/*---------------------------------------------------------------------------*/

int Disp_PutPointAtCenterOfScreen(Disp disp, int x, int y);

/*---------------------------------------------------------------------------*/
/* ����ե��å������꡼������ؤ�                                            */
/*---------------------------------------------------------------------------*/

int Disp_GraphicScreen(Disp disp);

/*---------------------------------------------------------------------------*/
/* �ƥ����ȥ����꡼������ؤ�                                                */
/*---------------------------------------------------------------------------*/

int Disp_TextScreen(Disp disp);

/*---------------------------------------------------------------------------*/
/* �ƥ����ȥ����꡼�󥯥ꥢ                                                  */
/*---------------------------------------------------------------------------*/

int Disp_ClearTextScreen(Disp disp);

/*---------------------------------------------------------------------------*/
/* ʸ������                                                                  */
/*---------------------------------------------------------------------------*/

int Disp_PutCharacter(Disp disp, int x, int y, unsigned int c);

/*---------------------------------------------------------------------------*/
/* ʸ��������                                                                */
/*---------------------------------------------------------------------------*/

int Disp_PutString(Disp disp, int x, int y, char * s);

/*---------------------------------------------------------------------------*/
/* ��������                                                                  */
/*---------------------------------------------------------------------------*/

int Disp_PutNumber(Disp disp, int x, int y, int len, int number);

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/

int Disp_ClearBar(Disp disp);

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/

int Disp_PrintScore(Disp disp, int hi_score, int score);

#endif

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
