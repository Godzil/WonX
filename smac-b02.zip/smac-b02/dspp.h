/*****************************************************************************/
/* Disp for WonderWitch                                                      */
/* �ǥ����ץ쥤��Ϣ�򰷤����饹                                              */
/*****************************************************************************/

#ifndef _DispP_h_INCLUDED_
#define _DispP_h_INCLUDED_

#include "dsp.h"

#define DISP_SPRITES_NUMBER 128
#define DISP_CHARACTERS_NUMBER 512
#define DISP_SPRITE_OFFSET 0
#define DISP_CHARACTER_OFFSET 0

typedef struct _Disp {
  int roll_x, roll_y;

  /* ���Ѥ��Ƥ륹�ץ饤���ֹ�Υӥåȥޥå� */
  unsigned char sprites[DISP_SPRITES_NUMBER / 8];

  /* ���Ѥ��Ƥ륭��饯�����ֹ�Υӥåȥޥå� */
  unsigned char characters[DISP_CHARACTERS_NUMBER / 8];
} _Disp;

#endif

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
