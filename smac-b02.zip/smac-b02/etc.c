#include <sys/timer.h>
#include <sys/system.h>

#include "etc.h"

void Error(char * funcname, char * message)
{
#if 0
  exit (1);
#endif
}

int initrand()
{
  unsigned int seed;

  seed =
    rtc_get_year() + rtc_get_month() + rtc_get_date() +
    rtc_get_day_of_week() + rtc_get_hour() + rtc_get_minute() +
    rtc_get_second() +
    sys_get_tick_count();

  srand(seed);
}

int getrand(int n)
{
  return (rand() % n);
}

/* End of file. */
