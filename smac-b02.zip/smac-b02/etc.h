#ifndef _etc_h_INCLUDED_
#define _etc_h_INCLUDED_

#include <stdio.h>
#include <stdlib.h>

void Error(char * funcname, char * message);
int initrand();
int getrand(int n);

#endif
