#include "gamep.h"

#include "etc.h"

Game Game_Create(Game game, Disp disp, int width, int height)
{
  game->disp = disp;
  game->width = width;
  game->height = height;
  game->stage_number = 1;
  game->player = Player_Create(&game->_player);
  if (game->player == NULL) return (NULL);

  return (game);
}

int Game_Start(Game game)
{
  int ret;

  do {

    game->stage = Stage_Create(&game->_stage, 
			       game->disp, game->width, game->height,
			       game->stage_number, game->player);
    if (game->stage == NULL) return (GAME_EXIT);
    ret = Stage_Start(game->stage);
    game->stage = Stage_Destroy(game->stage);

    if (ret == STAGE_EXIT) return (GAME_EXIT);
    if (ret == STAGE_FAILED) Player_DecreaseRest(game->player);
    else (game->stage_number)++;

  } while(Player_GetRest(game->player) > 0);

  return (GAME_REPLAY);
}

Game Game_Destroy(Game game)
{
  game->player = Player_Destroy(game->player);
  return (NULL);
}

/* End of File. */
