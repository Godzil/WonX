#ifndef _Game_h_INCLUDED_
#define _Game_h_INCLUDED_

typedef struct _Game * Game;

#include <stdlib.h>

#include "dsp.h"

#define GAME_REPLAY 0
#define GAME_EXIT   1

Game Game_Create(Game game, Disp disp, int width, int height);
int Game_Start(Game game);
Game Game_Destroy(Game game);

#endif

/* End of File. */
