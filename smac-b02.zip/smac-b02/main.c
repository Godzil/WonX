#include "smac.h"
#include "smacp.h"

void main(int argc, char * argv[])
{
  SpeedShooter smac;
  _SpeedShooter _smac;

  smac = SpeedShooter_Create(&_smac);
  if (smac != NULL) {
    SpeedShooter_Start(smac);
    smac = SpeedShooter_Destroy(smac);
  }
}
