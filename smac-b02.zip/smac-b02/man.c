#include "manp.h"

#include "etc.h"

#include "pic8/man_st_l.h"
#include "pic8/man_st_r.h"
#include "pic8/man_st_u.h"
#include "pic8/man_st_d.h"
#include "pic8/man_sh_l.h"
#include "pic8/man_sh_r.h"
#include "pic8/man_sh_u.h"
#include "pic8/man_sh_d.h"
#include "pic8/man_rf_l.h"
#include "pic8/man_rf_r.h"
#include "pic8/man_rf_u.h"
#include "pic8/man_rf_d.h"

#define MAN_STAND_LEFT_BITMAP_WIDTH   (man_stand_left_width*DISP_PICTURE_TICS_X)
#define MAN_STAND_LEFT_BITMAP_HEIGHT  (man_stand_left_height*DISP_PICTURE_TICS_Y)
#define MAN_STAND_LEFT_BITMAP_BITMAP  (void *)man_stand_left_bits
#define MAN_STAND_RIGHT_BITMAP_WIDTH  (man_stand_right_width*DISP_PICTURE_TICS_X)
#define MAN_STAND_RIGHT_BITMAP_HEIGHT (man_stand_right_height*DISP_PICTURE_TICS_Y)
#define MAN_STAND_RIGHT_BITMAP_BITMAP (void *)man_stand_right_bits
#define MAN_STAND_UP_BITMAP_WIDTH     (man_stand_up_width*DISP_PICTURE_TICS_X)
#define MAN_STAND_UP_BITMAP_HEIGHT    (man_stand_up_height*DISP_PICTURE_TICS_Y)
#define MAN_STAND_UP_BITMAP_BITMAP    (void *)man_stand_up_bits
#define MAN_STAND_DOWN_BITMAP_WIDTH   (man_stand_down_width*DISP_PICTURE_TICS_X)
#define MAN_STAND_DOWN_BITMAP_HEIGHT  (man_stand_down_height*DISP_PICTURE_TICS_Y)
#define MAN_STAND_DOWN_BITMAP_BITMAP  (void *)man_stand_down_bits

#define MAN_SHOOT_LEFT_BITMAP_WIDTH   (man_shoot_left_width*DISP_PICTURE_TICS_X)
#define MAN_SHOOT_LEFT_BITMAP_HEIGHT  (man_shoot_left_height*DISP_PICTURE_TICS_Y)
#define MAN_SHOOT_LEFT_BITMAP_BITMAP  (void *)man_shoot_left_bits
#define MAN_SHOOT_RIGHT_BITMAP_WIDTH  (man_shoot_right_width*DISP_PICTURE_TICS_X)
#define MAN_SHOOT_RIGHT_BITMAP_HEIGHT (man_shoot_right_height*DISP_PICTURE_TICS_Y)
#define MAN_SHOOT_RIGHT_BITMAP_BITMAP (void *)man_shoot_right_bits
#define MAN_SHOOT_UP_BITMAP_WIDTH     (man_shoot_up_width*DISP_PICTURE_TICS_X)
#define MAN_SHOOT_UP_BITMAP_HEIGHT    (man_shoot_up_height*DISP_PICTURE_TICS_Y)
#define MAN_SHOOT_UP_BITMAP_BITMAP    (void *)man_shoot_up_bits
#define MAN_SHOOT_DOWN_BITMAP_WIDTH   (man_shoot_down_width*DISP_PICTURE_TICS_X)
#define MAN_SHOOT_DOWN_BITMAP_HEIGHT  (man_shoot_down_height*DISP_PICTURE_TICS_Y)
#define MAN_SHOOT_DOWN_BITMAP_BITMAP  (void *)man_shoot_down_bits

#define MAN_RIFLE_LEFT_BITMAP_WIDTH   (man_rifle_left_width*DISP_PICTURE_TICS_X)
#define MAN_RIFLE_LEFT_BITMAP_HEIGHT  (man_rifle_left_height*DISP_PICTURE_TICS_Y)
#define MAN_RIFLE_LEFT_BITMAP_BITMAP  (void *)man_rifle_left_bits
#define MAN_RIFLE_RIGHT_BITMAP_WIDTH  (man_rifle_right_width*DISP_PICTURE_TICS_X)
#define MAN_RIFLE_RIGHT_BITMAP_HEIGHT (man_rifle_right_height*DISP_PICTURE_TICS_Y)
#define MAN_RIFLE_RIGHT_BITMAP_BITMAP (void *)man_rifle_right_bits
#define MAN_RIFLE_UP_BITMAP_WIDTH     (man_rifle_up_width*DISP_PICTURE_TICS_X)
#define MAN_RIFLE_UP_BITMAP_HEIGHT    (man_rifle_up_height*DISP_PICTURE_TICS_Y)
#define MAN_RIFLE_UP_BITMAP_BITMAP    (void *)man_rifle_up_bits
#define MAN_RIFLE_DOWN_BITMAP_WIDTH   (man_rifle_down_width*DISP_PICTURE_TICS_X)
#define MAN_RIFLE_DOWN_BITMAP_HEIGHT  (man_rifle_down_height*DISP_PICTURE_TICS_Y)
#define MAN_RIFLE_DOWN_BITMAP_BITMAP  (void *)man_rifle_down_bits

/*===========================================================================*/
/* ���֥������Ȥ������Ⱥ��                                                  */
/*===========================================================================*/

/*---------------------------------------------------------------------------*/
/* ����                                                                      */
/*---------------------------------------------------------------------------*/

Man Man_Create(Man man, Player player, Disp disp, Map map,
	       int x, int y, int dir)
{
  if (man == NULL) Error("Man_Create", "Cannot allocate memory.");

  man->player = player;
  man->x = x;
  man->y = y;
  man->dir = dir;
  man->status = MAN_STATUS_STAND;

  man->bullet = 6; /* �ƴݤο� */
  man->load_count = 0; /* �ƴ��佼�ѤΥ����� */
  man->gun = MAN_REVOLVER; /* ���Ƥν������ */
  man->speed_loader = MAN_NO_SPEED_LOADER; /* ���ԡ��ɡ����������ν������ */

  Map_Put(map, man->x, man->y, MAP_NONE);

  man->stand_picture[MAN_LEFT] =
    Picture_Create(&(man->_stand_picture[MAN_LEFT]), disp,
		   MAN_STAND_LEFT_BITMAP_WIDTH,
		   MAN_STAND_LEFT_BITMAP_HEIGHT,
		   MAN_STAND_LEFT_BITMAP_BITMAP);
  man->stand_picture[MAN_UP] =
    Picture_Create(&(man->_stand_picture[MAN_UP]), disp,
		   MAN_STAND_UP_BITMAP_WIDTH,
		   MAN_STAND_UP_BITMAP_HEIGHT,
		   MAN_STAND_UP_BITMAP_BITMAP);
  man->stand_picture[MAN_RIGHT] =
    Picture_Create(&(man->_stand_picture[MAN_RIGHT]), disp,
		   MAN_STAND_RIGHT_BITMAP_WIDTH,
		   MAN_STAND_RIGHT_BITMAP_HEIGHT,
		   MAN_STAND_RIGHT_BITMAP_BITMAP);
  man->stand_picture[MAN_DOWN] =
    Picture_Create(&(man->_stand_picture[MAN_DOWN]), disp,
		   MAN_STAND_DOWN_BITMAP_WIDTH,
		   MAN_STAND_DOWN_BITMAP_HEIGHT,
		   MAN_STAND_DOWN_BITMAP_BITMAP);

  man->shoot_picture[MAN_LEFT] =
    Picture_Create(&(man->_shoot_picture[MAN_LEFT]), disp,
		   MAN_SHOOT_LEFT_BITMAP_WIDTH,
		   MAN_SHOOT_LEFT_BITMAP_HEIGHT,
		   MAN_SHOOT_LEFT_BITMAP_BITMAP);
  man->shoot_picture[MAN_UP] =
    Picture_Create(&(man->_shoot_picture[MAN_UP]), disp,
		   MAN_SHOOT_UP_BITMAP_WIDTH,
		   MAN_SHOOT_UP_BITMAP_HEIGHT,
		   MAN_SHOOT_UP_BITMAP_BITMAP);
  man->shoot_picture[MAN_RIGHT] =
    Picture_Create(&(man->_shoot_picture[MAN_RIGHT]), disp,
		   MAN_SHOOT_RIGHT_BITMAP_WIDTH,
		   MAN_SHOOT_RIGHT_BITMAP_HEIGHT,
		   MAN_SHOOT_RIGHT_BITMAP_BITMAP);
  man->shoot_picture[MAN_DOWN] =
    Picture_Create(&(man->_shoot_picture[MAN_DOWN]), disp,
		   MAN_SHOOT_DOWN_BITMAP_WIDTH,
		   MAN_SHOOT_DOWN_BITMAP_HEIGHT,
		   MAN_SHOOT_DOWN_BITMAP_BITMAP);

  man->rifle_picture[MAN_LEFT] =
    Picture_Create(&(man->_rifle_picture[MAN_LEFT]), disp,
		   MAN_RIFLE_LEFT_BITMAP_WIDTH,
		   MAN_RIFLE_LEFT_BITMAP_HEIGHT,
		   MAN_RIFLE_LEFT_BITMAP_BITMAP);
  man->rifle_picture[MAN_UP] =
    Picture_Create(&(man->_rifle_picture[MAN_UP]), disp,
		   MAN_RIFLE_UP_BITMAP_WIDTH,
		   MAN_RIFLE_UP_BITMAP_HEIGHT,
		   MAN_RIFLE_UP_BITMAP_BITMAP);
  man->rifle_picture[MAN_RIGHT] =
    Picture_Create(&(man->_rifle_picture[MAN_RIGHT]), disp,
		   MAN_RIFLE_RIGHT_BITMAP_WIDTH,
		   MAN_RIFLE_RIGHT_BITMAP_HEIGHT,
		   MAN_RIFLE_RIGHT_BITMAP_BITMAP);
  man->rifle_picture[MAN_DOWN] =
    Picture_Create(&(man->_rifle_picture[MAN_DOWN]), disp,
		   MAN_RIFLE_DOWN_BITMAP_WIDTH,
		   MAN_RIFLE_DOWN_BITMAP_HEIGHT,
		   MAN_RIFLE_DOWN_BITMAP_BITMAP);

  man->character = Character_Create(&man->_character, disp,
				    man->stand_picture[man->dir], x, y);

  Character_Visible(man->character);
  Man_Locate(man, map, man->x, man->y, man->dir, man->status);

  return (man);
}

/*---------------------------------------------------------------------------*/
/* ���                                                                      */
/*---------------------------------------------------------------------------*/

Man Man_Destroy(Man man)
{
  int i;

  if (man == NULL) Error("Man_Destroy()", "Invalid object.");

  man->character = Character_Destroy(man->character);

  for (i = 0; i < 4; i++) {
    man->stand_picture[i] = Picture_Destroy(man->stand_picture[i]);
    man->shoot_picture[i] = Picture_Destroy(man->shoot_picture[i]);
    man->rifle_picture[i] = Picture_Destroy(man->rifle_picture[i]);
  }

  return (NULL);
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
