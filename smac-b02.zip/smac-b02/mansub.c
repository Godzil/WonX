#include "manp.h"

#include "etc.h"

/*===========================================================================*/
/* ���֥������Ȥ��ͤμ���                                                    */
/*===========================================================================*/

int Man_GetX(Man man)   { return (man->x); }
int Man_GetY(Man man)   { return (man->y); }
int Man_GetDir(Man man) { return (man->dir); }
Player Man_GetPlayer(Man man) { return (man->player); }

/*---------------------------------------------------------------------------*/
/* ����                                                                      */
/*---------------------------------------------------------------------------*/

int Man_Locate(Man man, Map map, int x, int y, int dir, int status)
{
  MapItem item;

  man->dir = dir;
  man->status = status;

  switch (man->status) {
  case MAN_STATUS_STAND:
    Character_SetPicture(man->character, man->stand_picture[man->dir]);
    break;
  case MAN_STATUS_SHOOT:
    Character_SetPicture(man->character, man->shoot_picture[man->dir]);
    break;
  case MAN_STATUS_RIFLE:
    Character_SetPicture(man->character, man->rifle_picture[man->dir]);
    break;
  }

  if (Map_IsAbleToMove(map, x, y)) {
    man->x = x;
    man->y = y;

    item = Map_Get(map, man->x, man->y);
    Map_Put(map, man->x, man->y, MAP_NONE);

    switch (item) {
    case MAP_DOLLAR: Player_AddScore(man->player, 0); break;
    case MAP_AUTOMATIC: man->gun = MAN_AUTOMATIC; Man_Reload(man); break;
    case MAP_RIFLE: man->gun = MAN_RIFLE; Man_Reload(man); break;
    case MAP_GOLD: Player_AddScore(man->player, 10); break;
    case MAP_SPEED_LOADER: man->speed_loader = MAN_SPEED_LOADER; break;
    case MAP_MAN_1UP: Player_IncreaseRest(man->player); break;
    }

    Character_Locate(man->character, man->x, man->y);
    Character_PutCharacterAtCenterOfScreen(man->character);
    /* Character_PutCharacterAtCenterOfScreen(man->character); ��
       roll_x,roll_y�����Ѥ��Τǡ��Ƥ�
       Character_Locate(man->character, man->x, man->y);
       ����ɬ�פ����롥
       */
    Character_Locate(man->character, man->x, man->y);
  }

  return (0);
}

/*---------------------------------------------------------------------------*/
/* ��ư                                                                      */
/*---------------------------------------------------------------------------*/

int Man_Move(Man man, Map map, int dir)
{
  int x, y;

  x = man->x;
  y = man->y;

  switch (dir) {
  case MAN_UP    : y--; break;
  case MAN_DOWN  : y++; break;
  case MAN_LEFT  : x--; break;
  case MAN_RIGHT : x++; break;
  }

  Man_Locate(man, map, x, y, dir, MAN_STATUS_STAND);

  return (man->dir);
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
