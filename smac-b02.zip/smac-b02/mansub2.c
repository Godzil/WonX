#include "manp.h"

#include "etc.h"

/*---------------------------------------------------------------------------*/
/* �ƹ���                                                                    */
/*---------------------------------------------------------------------------*/

int Man_Reload(Man man)
{
  switch (man->gun) {
  case MAN_REVOLVER  : man->bullet = MAN_REVOLVER_BULLET;  break;
  case MAN_AUTOMATIC : man->bullet = MAN_AUTOMATIC_BULLET; break;
  case MAN_RIFLE     : man->bullet = MAN_RIFLE_BULLET;     break;
  }
  return (0);
}

int Man_Load(Man man, Map map)
{
  if (man->bullet > 0) return (1);

  Man_Locate(man, map, man->x, man->y, man->dir, MAN_STATUS_STAND);

  man->load_count++;

  if ( (man->speed_loader == MAN_SPEED_LOADER) &&
       (man->load_count < MAN_SPEED_LOADER_COUNT) )
    return (0);
  if ( (man->speed_loader == MAN_NO_SPEED_LOADER) &&
       (man->load_count < MAN_NO_SPEED_LOADER_COUNT) )
    return (0);

  man->load_count = 0;

  Man_Reload(man);

  return (0);
}

/*---------------------------------------------------------------------------*/
/* �ͷ�                                                                      */
/*---------------------------------------------------------------------------*/

int Man_Shoot(Man man, Map map, int monsters_number, Monster monsters[])
{
  int x, y, i, j, n;
  int vx, vy;
  MapItem item;

  if (man->bullet == 0) return (Man_Load(man, map));

  if (man->gun == MAN_RIFLE) {
    n = 3;
    Man_Locate(man, map, man->x, man->y, man->dir, MAN_STATUS_RIFLE);
  } else {
    n = 1;
    Man_Locate(man, map, man->x, man->y, man->dir, MAN_STATUS_SHOOT);
  }

  vx = vy = 0;
  switch (man->dir) {
  case MAN_LEFT  : vx = -1; break;
  case MAN_RIGHT : vx =  1; break;
  case MAN_UP    : vy = -1; break;
  case MAN_DOWN  : vy =  1; break;
  default        : return (1);
  }

  x = man->x;
  y = man->y;

  for (i = 0; i < n; i++) {

    if (man->bullet <= 0) continue;
    man->bullet--;

    while (1) {
      x += vx;
      y += vy;

      if (!Map_IsInside(map, x, y)) {
	x -= vx;
	y -= vy;
	Map_Explode(map, x, y);
	break;
      }

      for (j = 0; j < monsters_number; j++) {
	if( (Monster_GetX(monsters[j]) == x) &&
	    (Monster_GetY(monsters[j]) == y) ) {
	  Monster_Explode(monsters[j], map, man);
	  Player_AddScore(man->player, 1);
	  break;
	}
      }
      if (j < monsters_number) {
	x -= vx;
	y -= vy;
	break;
      }

      item = Map_Get(map, x, y);

      if (item == MAP_NONE) continue;

      if (item == MAP_BLOCK) {
	x -= vx;
	y -= vy;
	Map_Explode(map, x, y);
	break;
      }

      if ( (item == MAP_BRITTLE_BLOCK1) ||
	   (item == MAP_BRITTLE_BLOCK2) ||
	   (item == MAP_BRITTLE_BLOCK3) ||
	   (item == MAP_BRITTLE_BLOCK4) ||
	   (item == MAP_BRITTLE_BLOCK5) ||
	   (item == MAP_BRITTLE_BLOCK6) ) {
	Map_Explode(map, x, y);
	x -= vx;
	y -= vy;
	Map_Explode(map, x, y);
	break;
      }

      if (item == MAP_DOLLAR) {
	Map_Explode(map, x, y);
	Player_AddScore(man->player, 3);
	break;
      }

      if ( (item == MAP_AUTOMATIC) ||
	   (item == MAP_RIFLE) ||
	   (item ==  MAP_GOLD) ||
	   (item ==  MAP_SPEED_LOADER) ||
	   (item ==  MAP_MAN_1UP) ) {
	Map_Explode(map, x, y);
	break;
      }
    }
  }

  return (0);
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
