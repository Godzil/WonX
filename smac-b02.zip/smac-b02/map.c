#include "mapp.h"

#include "etc.h"

#include "pic8/none.h"
#include "pic8/block.h"
#include "pic8/dollar.h"
#include "pic8/auto.h"
#include "pic8/rifle.h"
#include "pic8/gold.h"
#include "pic8/speed.h"
#include "pic8/man_1up.h"
#include "pic8/explode1.h"
#include "pic8/explode2.h"
#include "pic8/explode3.h"

#define NONE_BITMAP_WIDTH  (none_width*DISP_PICTURE_TICS_X)
#define NONE_BITMAP_HEIGHT (none_height*DISP_PICTURE_TICS_Y)
#define NONE_BITMAP_BITMAP (void *)none_bits

#define BLOCK_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BLOCK_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BLOCK_BITMAP_BITMAP (void *)block_bits

#define DOLLAR_BITMAP_WIDTH  (dollar_width*DISP_PICTURE_TICS_X)
#define DOLLAR_BITMAP_HEIGHT (dollar_height*DISP_PICTURE_TICS_Y)
#define DOLLAR_BITMAP_BITMAP (void *)dollar_bits

#define BRITTLE_BLOCK1_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK1_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK1_BITMAP_BITMAP (void *)block_bits

#define BRITTLE_BLOCK2_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK2_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK2_BITMAP_BITMAP (void *)block_bits

#define BRITTLE_BLOCK3_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK3_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK3_BITMAP_BITMAP (void *)block_bits

#define BRITTLE_BLOCK4_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK4_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK4_BITMAP_BITMAP (void *)block_bits

#define BRITTLE_BLOCK5_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK5_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK5_BITMAP_BITMAP (void *)block_bits

#define BRITTLE_BLOCK6_BITMAP_WIDTH  (block_width*DISP_PICTURE_TICS_X)
#define BRITTLE_BLOCK6_BITMAP_HEIGHT (block_height*DISP_PICTURE_TICS_Y)
#define BRITTLE_BLOCK6_BITMAP_BITMAP (void *)block_bits

#define AUTOMATIC_BITMAP_WIDTH  (auto_width*DISP_PICTURE_TICS_X)
#define AUTOMATIC_BITMAP_HEIGHT (auto_height*DISP_PICTURE_TICS_Y)
#define AUTOMATIC_BITMAP_BITMAP (void *)auto_bits

#define RIFLE_BITMAP_WIDTH  (rifle_width*DISP_PICTURE_TICS_X)
#define RIFLE_BITMAP_HEIGHT (rifle_height*DISP_PICTURE_TICS_Y)
#define RIFLE_BITMAP_BITMAP (void *)rifle_bits

#define GOLD_BITMAP_WIDTH  (gold_width*DISP_PICTURE_TICS_X)
#define GOLD_BITMAP_HEIGHT (gold_height*DISP_PICTURE_TICS_Y)
#define GOLD_BITMAP_BITMAP (void *)gold_bits

#define SPEED_LOADER_BITMAP_WIDTH  (speed_width*DISP_PICTURE_TICS_X)
#define SPEED_LOADER_BITMAP_HEIGHT (speed_height*DISP_PICTURE_TICS_Y)
#define SPEED_LOADER_BITMAP_BITMAP (void *)speed_bits

#define MAN_1UP_BITMAP_WIDTH  (man_1up_width*DISP_PICTURE_TICS_X)
#define MAN_1UP_BITMAP_HEIGHT (man_1up_height*DISP_PICTURE_TICS_Y)
#define MAN_1UP_BITMAP_BITMAP (void *)man_1up_bits

#define EXPLODE1_BITMAP_WIDTH  (explode1_width*DISP_PICTURE_TICS_X)
#define EXPLODE1_BITMAP_HEIGHT (explode1_height*DISP_PICTURE_TICS_Y)
#define EXPLODE1_BITMAP_BITMAP (void *)explode1_bits

#define EXPLODE2_BITMAP_WIDTH  (explode2_width*DISP_PICTURE_TICS_X)
#define EXPLODE2_BITMAP_HEIGHT (explode2_height*DISP_PICTURE_TICS_Y)
#define EXPLODE2_BITMAP_BITMAP (void *)explode2_bits

#define EXPLODE3_BITMAP_WIDTH  (explode3_width*DISP_PICTURE_TICS_X)
#define EXPLODE3_BITMAP_HEIGHT (explode3_height*DISP_PICTURE_TICS_Y)
#define EXPLODE3_BITMAP_BITMAP (void *)explode3_bits

/*===========================================================================*/
/* ���֥������Ȥ������Ⱥ��                                                  */
/*===========================================================================*/

/*---------------------------------------------------------------------------*/
/* ����                                                                      */
/*---------------------------------------------------------------------------*/

Map Map_Create(Map map, Disp disp, int width, int height)
{
  int i, w, h;
  unsigned char * bitmap;

  if (map == NULL) Error("Map_Create", "Cannot allocate memory.");

  if ( (width  < 0) || (height < 0) ) {
    Error("Map_Create", "Invalid width or height size");
  }

  if ( (width  > MAP_MAX_WIDTH ) || (height > MAP_MAX_HEIGHT) ) {
    Error("Map_Create", "Width or height size is too big");
  }

  map->width  = width;
  map->height = height;

  for (i = 0; i < MAP_ITEM_NUMBER; i++) {
    switch (i) {
    case MAP_NONE:
      w = NONE_BITMAP_WIDTH; h = NONE_BITMAP_HEIGHT;
      bitmap = NONE_BITMAP_BITMAP;
      break;
    case MAP_BLOCK:
      w = BLOCK_BITMAP_WIDTH; h = BLOCK_BITMAP_HEIGHT;
      bitmap = BLOCK_BITMAP_BITMAP;
      break;
    case MAP_DOLLAR:
      w = DOLLAR_BITMAP_WIDTH; h = DOLLAR_BITMAP_HEIGHT;
      bitmap = DOLLAR_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK1:
      w = BRITTLE_BLOCK1_BITMAP_WIDTH; h = BRITTLE_BLOCK1_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK1_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK2:
      w = BRITTLE_BLOCK2_BITMAP_WIDTH; h = BRITTLE_BLOCK2_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK2_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK3:
      w = BRITTLE_BLOCK3_BITMAP_WIDTH; h = BRITTLE_BLOCK3_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK3_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK4:
      w = BRITTLE_BLOCK4_BITMAP_WIDTH; h = BRITTLE_BLOCK4_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK4_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK5:
      w = BRITTLE_BLOCK5_BITMAP_WIDTH; h = BRITTLE_BLOCK5_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK5_BITMAP_BITMAP;
      break;
    case MAP_BRITTLE_BLOCK6:
      w = BRITTLE_BLOCK6_BITMAP_WIDTH; h = BRITTLE_BLOCK6_BITMAP_HEIGHT;
      bitmap = BRITTLE_BLOCK6_BITMAP_BITMAP;
      break;
    case MAP_AUTOMATIC:
      w = AUTOMATIC_BITMAP_WIDTH; h = AUTOMATIC_BITMAP_HEIGHT;
      bitmap = AUTOMATIC_BITMAP_BITMAP;
      break;
    case MAP_RIFLE:
      w = RIFLE_BITMAP_WIDTH; h = RIFLE_BITMAP_HEIGHT;
      bitmap = RIFLE_BITMAP_BITMAP;
      break;
    case MAP_GOLD:
      w = GOLD_BITMAP_WIDTH; h = GOLD_BITMAP_HEIGHT;
      bitmap = GOLD_BITMAP_BITMAP;
      break;
    case MAP_SPEED_LOADER:
      w = SPEED_LOADER_BITMAP_WIDTH; h = SPEED_LOADER_BITMAP_HEIGHT;
      bitmap = SPEED_LOADER_BITMAP_BITMAP;
      break;
    case MAP_MAN_1UP:
      w = MAN_1UP_BITMAP_WIDTH; h = MAN_1UP_BITMAP_HEIGHT;
      bitmap = MAN_1UP_BITMAP_BITMAP;
      break;
    case MAP_EXPLODE1:
      w = EXPLODE1_BITMAP_WIDTH; h = EXPLODE1_BITMAP_HEIGHT;
      bitmap = EXPLODE1_BITMAP_BITMAP;
      break;
    case MAP_EXPLODE2:
      w = EXPLODE2_BITMAP_WIDTH; h = EXPLODE2_BITMAP_HEIGHT;
      bitmap = EXPLODE2_BITMAP_BITMAP;
      break;
    case MAP_EXPLODE3:
      w = EXPLODE3_BITMAP_WIDTH; h = EXPLODE3_BITMAP_HEIGHT;
      bitmap = EXPLODE3_BITMAP_BITMAP;
      break;
    default:
      return (NULL);
    }
    map->pictures[i] =
      Picture_Create(&(map->_pictures[i]), disp, w, h, bitmap);
  }

  Map_Clear(map);
  Map_Make(map);

  return (map);
}

/*---------------------------------------------------------------------------*/
/* ���                                                                      */
/*---------------------------------------------------------------------------*/

Map Map_Destroy(Map map)
{
  int i;

  if (map == NULL) Error("Map_Destroy()", "Invalid object.");

  for (i = 0; i < MAP_ITEM_NUMBER; i++) {
    if (map->pictures[i]) map->pictures[i] = Picture_Destroy(map->pictures[i]);
  }

  return (NULL);
}

/* End of File. */
