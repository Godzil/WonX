#ifndef _Map_h_INCLUDED_
#define _Map_h_INCLUDED_

typedef struct _Map * Map;

#include <stdio.h>

#include "dsp.h"

typedef enum {
  MAP_NONE, /* 0 */
  MAP_BLOCK,
  MAP_DOLLAR,
  MAP_BRITTLE_BLOCK1,
  MAP_BRITTLE_BLOCK2,
  MAP_BRITTLE_BLOCK3,
  MAP_BRITTLE_BLOCK4,
  MAP_BRITTLE_BLOCK5,
  MAP_BRITTLE_BLOCK6,
  MAP_AUTOMATIC,
  MAP_RIFLE,
  MAP_GOLD,
  MAP_SPEED_LOADER,
  MAP_MAN_1UP,
  MAP_EXPLODE1,
  MAP_EXPLODE2,
  MAP_EXPLODE3,
  MAP_ITEM_END
} MapItem;

#define MAP_OUTSIDE MAP_ITEM_END
#define MAP_ITEM_NUMBER (MAP_ITEM_END)

int Map_GetWidth(Map map);
int Map_GetHeight(Map map);
Map Map_Create(Map map, Disp disp, int width, int height);
Map Map_Destroy(Map map);
int Map_Clear(Map map);
int Map_Make(Map map);
int Map_IsInside(Map map, int x, int y);
MapItem Map_Get(Map map, int x, int y);
MapItem Map_Put(Map map, int x, int y, MapItem item);
unsigned char Map_IsAbleToMove(Map map, int x, int y);
int Map_Explode(Map map, int x, int y);

#endif

/* End of File. */
