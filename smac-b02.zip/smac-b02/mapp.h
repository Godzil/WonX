#ifndef _MapP_h_INCLUDED_
#define _MapP_h_INCLUDED_

#include "map.h"
#include "picturep.h"

#define MAP_MAX_WIDTH  DISP_SCREEN_CHARACTER_WIDTH
#define MAP_MAX_HEIGHT DISP_SCREEN_CHARACTER_HEIGHT

/* Map ���֥������� */
typedef struct _Map {
  int width, height;

  Picture pictures[MAP_ITEM_NUMBER];
  _Picture _pictures[MAP_ITEM_NUMBER];

  MapItem map[MAP_MAX_WIDTH][MAP_MAX_HEIGHT];
} _Map;

#endif

/* End of program */
