#include "mapp.h"

#include <sys/system.h>

#include "etc.h"

int Map_GetWidth(Map map) { return (map->width); }
int Map_GetHeight(Map map) { return (map->height); }

/*---------------------------------------------------------------------------*/
/* ���ꥢ                                                                    */
/*---------------------------------------------------------------------------*/

int Map_Clear(Map map)
{
  int x, y;

  for (x = 0; x < map->width; x++) {
    for (y = 0; y < map->height; y++) {
      Map_Put(map, x, y, MAP_NONE);
    }
  }

  return (0);
}

/*---------------------------------------------------------------------------*/
/* �ޥåפκ���                                                              */
/*---------------------------------------------------------------------------*/

int Map_Make(Map map)
{
  int x, y;
  MapItem ch;

  for (x = 0; x < map->width; x++) {
    for (y = 0; y < map->height; y++) {
      do {
	ch = MAP_NONE;
	if (getrand(100) < 50) { ch = MAP_NONE;   break; }
	if (getrand(100) < 40) { ch = MAP_BLOCK;  break; }
	if (getrand(100) < 50) { ch = MAP_DOLLAR; break; }

	if (getrand(100) < 20) { ch = MAP_BRITTLE_BLOCK3; break; }
	if (getrand(100) < 20) { ch = MAP_BRITTLE_BLOCK6; break; }

	if (getrand(100) <  2) { ch = MAP_GOLD; break; }
	if (getrand(100) <  1) { ch = MAP_SPEED_LOADER; break; }
	if (getrand(100) <  1) { ch = MAP_AUTOMATIC; break; }
	if (getrand(100) <  1) { ch = MAP_RIFLE; break; }
	if (getrand(1000)<  1) { ch = MAP_MAN_1UP; break; }
      } while (0);
      Map_Put(map, x, y, ch);
    }
  }

  return (0);
}

/*---------------------------------------------------------------------------*/
/* */
/*---------------------------------------------------------------------------*/

int Map_IsInside(Map map, int x, int y)
{
  if ( (x < 0) || (x > map->width  - 1) ||
       (y < 0) || (y > map->height - 1) ) { return (0); }
  return (1);
}

MapItem Map_Get(Map map, int x, int y)
{
  if (!Map_IsInside(map, x, y)) { return (MAP_OUTSIDE); }
  return (map->map[x][y]);
}

/*---------------------------------------------------------------------------*/
/* */
/*---------------------------------------------------------------------------*/

MapItem Map_Put(Map map, int x, int y, MapItem item)
{
  if (!Map_IsInside(map, x, y)) { return (MAP_OUTSIDE); }

  if (item == MAP_OUTSIDE) return (MAP_OUTSIDE);
  if ( (item < 0) || (item > MAP_ITEM_NUMBER - 1) ) return (MAP_OUTSIDE);

  Picture_Put(map->pictures[item], x, y);

  return (map->map[x][y] = item);
}

/*---------------------------------------------------------------------------*/
/* */
/*---------------------------------------------------------------------------*/

unsigned char Map_IsAbleToMove(Map map, int x, int y)
{
  if (!Map_IsInside(map, x, y)) { return (0); }

  if ( (map->map[x][y] == MAP_BLOCK         ) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK1) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK2) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK3) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK4) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK5) ||
       (map->map[x][y] == MAP_BRITTLE_BLOCK6) ) return (0);

  return (1);
}

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

int Map_Explode(Map map, int x, int y)
{
  if (!Map_IsInside(map, x, y)) { return (1); }

  switch (map->map[x][y]) {

  case MAP_NONE :
  case MAP_DOLLAR :
  case MAP_AUTOMATIC :
  case MAP_RIFLE :
  case MAP_GOLD :
  case MAP_SPEED_LOADER :
  case MAP_MAN_1UP :
    switch (getrand(3)) {
    case 0: Map_Put(map, x, y, MAP_EXPLODE1); break;
    case 1: Map_Put(map, x, y, MAP_EXPLODE2); break;
    case 2: Map_Put(map, x, y, MAP_EXPLODE3); break;
    }
    sys_wait(4);
    Map_Put(map, x, y, MAP_NONE);
    break;

  case MAP_BRITTLE_BLOCK6 : Map_Put(map, x, y, MAP_BRITTLE_BLOCK5); break;
  case MAP_BRITTLE_BLOCK5 : Map_Put(map, x, y, MAP_BRITTLE_BLOCK4); break;
  case MAP_BRITTLE_BLOCK4 : Map_Put(map, x, y, MAP_BRITTLE_BLOCK3); break;
  case MAP_BRITTLE_BLOCK3 : Map_Put(map, x, y, MAP_BRITTLE_BLOCK2); break;
  case MAP_BRITTLE_BLOCK2 : Map_Put(map, x, y, MAP_BRITTLE_BLOCK1); break;
  case MAP_BRITTLE_BLOCK1 : Map_Put(map, x, y, MAP_NONE          ); break;

  default : return (1);
  }

  return (0);
}



/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

/* End of File. */
