#include "menup.h"

#include <sys/system.h>

#include "etc.h"

Menu Menu_Create(Menu menu, Disp disp)
{
  menu->disp = disp;
  Disp_TextScreen(menu->disp);
  Disp_ClearTextScreen(menu->disp);
  return (menu);
}

int Menu_Start(Menu menu)
{
  int k;

  Disp_PutString(menu->disp, 0,  1, "          SpeedMac          ");
  Disp_PutString(menu->disp, 0,  2, " - Mac the Speed Shooter -  ");

  Disp_PutString(menu->disp, 0,  4, "       Key Operations       ");
  Disp_PutString(menu->disp, 0,  5, "  X1,2,3,4 - Move           ");
  Disp_PutString(menu->disp, 0,  6, "  Button A - Shoot or Load  ");
  Disp_PutString(menu->disp, 0,  7, "  START    - Exit           ");

  Disp_PutString(menu->disp, 0,  9, " You have 6 bullets and push");
  Disp_PutString(menu->disp, 0, 10, "button A to shoot them. If  ");
  Disp_PutString(menu->disp, 0, 11, "you finish shooting, push   ");
  Disp_PutString(menu->disp, 0, 12, "button A for 10 times to re-");
  Disp_PutString(menu->disp, 0, 13, "load bullets.               ");

  Disp_PutString(menu->disp, 0, 15, "Push Button A to Start Game!");

  Disp_PutString(menu->disp, 0, 17, "Copyright (c) SAKAI Hiroaki.");

  while (1) {
    k = Disp_GetButtonStatus(menu->disp);
    if (k & DISP_BUTTON_A) break;
    if (k & DISP_BUTTON_START) break;
    sys_wait(5);
  }

  if (k & DISP_BUTTON_START) return (MENU_EXIT);
  return (MENU_GAME_START);
}

Menu Menu_Destroy(Menu menu)
{
  Disp_ClearTextScreen(menu->disp);
  Disp_GraphicScreen(menu->disp);
  return (NULL);
}

/* End of File. */
