#ifndef _Menu_h_INCLUDED_
#define _Menu_h_INCLUDED_

typedef struct _Menu * Menu;

#include <stdlib.h>

#include "dsp.h"

#define MENU_EXIT       0
#define MENU_GAME_START 1

Menu Menu_Create(Menu menu, Disp disp);
int Menu_Start(Menu menu);
Menu Menu_Destroy(Menu menu);

#endif

/* End of File. */
