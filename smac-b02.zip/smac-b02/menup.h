#ifndef _MenuP_h_INCLUDED_
#define _MenuP_h_INCLUDED_

#include "menu.h"

typedef struct _Menu {
  Disp disp;
} _Menu;

#endif

/* End of File. */
