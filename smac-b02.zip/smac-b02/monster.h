#ifndef _Monster_h_INCLUDED_
#define _Monster_h_INCLUDED_

typedef struct _Monster * Monster;

#include <stdio.h>

#include "dsp.h"
#include "map.h"
#include "man.h"

/* ��󥹥����θ��� */
#define MONSTER_LEFT  0 /* ������ */
#define MONSTER_UP    1 /* ����� */
#define MONSTER_RIGHT 2 /* ������ */
#define MONSTER_DOWN  3 /* ������ */

/* ��󥹥����Υ����� */
#define MONSTER_TYPE_OIKAKE    0
#define MONSTER_TYPE_OTOBOKE   1
#define MONSTER_TYPE_CHOKUSHIN 2
#define MONSTER_TYPE_KIMAGURE  3

int Monster_GetX(Monster monster);
int Monster_GetY(Monster monster);
int Monster_GetSpeed(Monster monster);
int Monster_GetCounter(Monster monster);
Monster Monster_Create(Monster monster, Disp disp, Map map,
		       int x, int y, int dir, int type, int speed);
Monster Monster_Destroy(Monster monster);
int Monster_Move(Monster monster, Map map, Man man);
int Monster_Explode(Monster monster, Map map, Man man);

#endif

/* End of File. */
