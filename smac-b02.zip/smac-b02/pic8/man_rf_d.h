#define man_rifle_down_width  1
#define man_rifle_down_height 1
unsigned char man_rifle_down_bits[] = {
	0x80, 0x90, 0xFE, 0x3E, 0xD8, 0x88, 0x08, 0x08, 

};
