#define man_rifle_left_width  1
#define man_rifle_left_height 1
unsigned char man_rifle_left_bits[] = {
	0x00, 0x0C, 0x0C, 0xFC, 0x1E, 0x0C, 0x14, 0x37, 

};
