#define man_rifle_right_width  1
#define man_rifle_right_height 1
unsigned char man_rifle_right_bits[] = {
	0x00, 0x30, 0x30, 0x3F, 0x78, 0x30, 0x28, 0xEC, 

};
