#define man_shoot_down_width  1
#define man_shoot_down_height 1
unsigned char man_shoot_down_bits[] = {
	0x90, 0xF8, 0x1F, 0xEB, 0x88, 0x0C, 0x04, 0x04, 

};
