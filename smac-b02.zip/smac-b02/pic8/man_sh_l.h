#define man_shoot_left_width  1
#define man_shoot_left_height 1
unsigned char man_shoot_left_bits[] = {
	0x0C, 0x0C, 0xE4, 0x3E, 0x07, 0x0A, 0x0A, 0x1B, 

};
