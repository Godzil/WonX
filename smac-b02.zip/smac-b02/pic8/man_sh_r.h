#define man_shoot_right_width  1
#define man_shoot_right_height 1
unsigned char man_shoot_right_bits[] = {
	0x30, 0x30, 0x27, 0x7C, 0xE0, 0x50, 0x50, 0xD8, 

};
