#define man_stand_down_width  1
#define man_stand_down_height 1
unsigned char man_stand_down_bits[] = {
	0x00, 0xD8, 0xA8, 0x1F, 0xEB, 0x90, 0x10, 0x20, 

};
