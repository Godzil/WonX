#define man_stand_left_width  1
#define man_stand_left_height 1
unsigned char man_stand_left_bits[] = {
	0x18, 0x18, 0x08, 0x1E, 0x6A, 0x94, 0x12, 0x36, 

};
