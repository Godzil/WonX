#define man_stand_right_width  1
#define man_stand_right_height 1
unsigned char man_stand_right_bits[] = {
	0x18, 0x18, 0x10, 0x78, 0x56, 0x29, 0x48, 0x6C, 

};
