/*****************************************************************************/
/* Picture class for WonderWitch                                             */
/* ����饯�����ʤɤβ����򰷤����饹                                        */
/*****************************************************************************/

#include "picturep.h"

#include "etc.h"

int Picture_GetWidth( Picture picture) { return (picture->width ); }
int Picture_GetHeight(Picture picture) { return (picture->height); }

/*---------------------------------------------------------------------------*/
/* ����饯���ֹ�μ���                                                      */
/*---------------------------------------------------------------------------*/

int Picture_GetNumber(Picture picture) { return (picture->number); }

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥ�����                                                        */
/*---------------------------------------------------------------------------*/

Picture Picture_Create(Picture picture, Disp disp, int width, int height,
		       unsigned char bitmap[])
{
  if (picture == NULL) Error("Picture_Create", "Cannot allocate memory.");

  picture->disp = disp;
  picture->number = Disp_GetCharacterNumber(picture->disp);
  picture->width  = width;
  picture->height = height;

  /* WonderWitch �ξ��ϡ��礭����ɬ�� 8x8 �ˤʤ롥 */
  if ((picture->width != 8) || (picture->height != 8))
    Error("Picture_Create", "Invalid size.");

  font_set_monodata(picture->number, 1, bitmap);

  return (picture);
}

/*---------------------------------------------------------------------------*/
/* ���֥������Ȥκ��                                                        */
/*---------------------------------------------------------------------------*/

Picture Picture_Destroy(Picture picture)
{
  /* ����饯���ֹ�� Disp ���֥������Ȥ��֤��� */
  Disp_ReturnCharacterNumber(picture->disp, picture->number);
  return (NULL);
}

/*---------------------------------------------------------------------------*/
/* ����                                                                      */
/*---------------------------------------------------------------------------*/

int Picture_Put(Picture picture, int x, int y)
{
  screen_fill_char(SCREEN2, x, y, 1, 1, picture->number);
  return (0);
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
