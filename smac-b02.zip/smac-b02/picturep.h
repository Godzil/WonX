/*****************************************************************************/
/* Picture class for WonderWitch                                             */
/* �����򰷤����饹                                                          */
/*****************************************************************************/

#ifndef _PictureP_h_INCLUDED_
#define _PictureP_h_INCLUDED_

#include "picture.h"

typedef struct _Picture {
  Disp disp;
  int number; /* ����饯���ֹ� */
  int width, height; /* �������礭�� */
} _Picture;

#endif /* _PictureP_h_INCLUDED_ */

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
