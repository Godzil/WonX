#include "playerp.h"

#include "etc.h"

int Player_GetScore(Player player) { return (player->score); }

int Player_AddScore(Player player, int score)
{
  player->score += score;
  return (player->score);
}

int Player_GetRest(Player player) { return (player->rest); }

int Player_IncreaseRest(Player player)
{
  (player->rest)++;
  return (player->rest > 0);
}

int Player_DecreaseRest(Player player)
{
  (player->rest)--;
  return (player->rest > 0);
}

int Player_SetMan(Player player, Man man)
{
  player->man = man;
  return (0);
}

Player Player_Create(Player player)
{
  player->score = 0;
  player->rest = PLAYER_DEFAULT_REST;
  return (player);
}

Player Player_Destroy(Player player)
{
  if (player == NULL) Error("Player_Destroy", "Invalid object");
  return (NULL);
}

/* End of File. */
