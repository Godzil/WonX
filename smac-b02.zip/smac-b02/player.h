#ifndef _Player_h_INCLUDED_
#define _Player_h_INCLUDED_

typedef struct _Player * Player;

#include "man.h"

int Player_GetScore(Player player);
int Player_AddScore(Player player, int score);
int Player_GetRest(Player player);
int Player_IncreaseRest(Player player);
int Player_DecreaseRest(Player player);
int Player_SetMan(Player player, Man man);
Player Player_Create(Player player);
Player Player_Destroy(Player player);

#endif

/* End of File. */
