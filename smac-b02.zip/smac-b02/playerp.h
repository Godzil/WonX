#ifndef _PlayerP_h_INCLUDED_
#define _PlayerP_h_INCLUDED_

#include "player.h"

#define PLAYER_DEFAULT_REST 3

typedef struct _Player {
  int score;
  int rest;
  Man man;
} _Player;

#endif

/* End of File. */
