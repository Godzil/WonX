#include "smacp.h"

#include "etc.h"

SpeedShooter SpeedShooter_Create(SpeedShooter speed_shooter)
{
  initrand();

  speed_shooter->disp = Disp_Create(&speed_shooter->_disp);
  if (speed_shooter->disp == NULL) return (NULL);
  return (speed_shooter);
}

int SpeedShooter_Start(SpeedShooter speed_shooter)
{
  int ret;

  /* ������Υᥤ��롼��(��˥塼���򡤥�����Υץ쥤) */
  while (1) {

    /* ��˥塼���� */
    speed_shooter->menu =
      Menu_Create(&speed_shooter->_menu, speed_shooter->disp);
    if (speed_shooter->menu == NULL) return (1);
    ret = Menu_Start(speed_shooter->menu);
    speed_shooter->menu = Menu_Destroy(speed_shooter->menu);
    if (ret == MENU_EXIT) break;

    /* ������Υץ쥤 */
    speed_shooter->game = Game_Create(&speed_shooter->_game,
				      speed_shooter->disp,
				      DISP_SCREEN_CHARACTER_WIDTH,
				      DISP_SCREEN_CHARACTER_HEIGHT);
    if (speed_shooter->game == NULL) return (SPEEDMAC_EXIT);
    ret = Game_Start(speed_shooter->game);
    speed_shooter->game = Game_Destroy(speed_shooter->game);
    if (ret == GAME_EXIT) return (SPEEDMAC_EXIT);
  }

  return (SPEEDMAC_EXIT);
}

SpeedShooter SpeedShooter_Destroy(SpeedShooter speed_shooter)
{
  speed_shooter->disp = Disp_Destroy(speed_shooter->disp);
  return (NULL);
}

/* End of File. */
