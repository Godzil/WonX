#ifndef _SpeedShooter_H_INCLUDED_
#define _SpeedShooter_H_INCLUDED_

typedef struct _SpeedShooter * SpeedShooter;

#include <stdio.h>

#define SPEEDMAC_EXIT 0

SpeedShooter SpeedShooter_Create(SpeedShooter speed_shooter);
int SpeedShooter_Start(SpeedShooter speed_shooter);
SpeedShooter SpeedShooter_Destroy(SpeedShooter speed_shooter);

#endif

/* End of File. */
