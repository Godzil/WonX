#include "stagep.h"

#include <sys/system.h>

#include "etc.h"

Stage Stage_Create(Stage stage, Disp disp, int width, int height,
		   int stage_number, Player player)
{
  int i, x, y;
  int speed;

  stage->disp = disp;
  stage->width = width;
  stage->height = height;
  stage->number = stage_number;

  stage->map = Map_Create(&stage->_map, stage->disp,
			  stage->width, stage->height);
  if (stage->map == NULL) return (NULL);

  stage->man = Man_Create(&stage->_man, player, stage->disp, stage->map,
			  stage->width / 2, stage->height / 2, MAN_RIGHT);
  if (stage->man == NULL) return (NULL);

  Player_SetMan(player, stage->man);

  Map_Put(stage->map, Man_GetX(stage->man)-1,Man_GetY(stage->man)  , MAP_NONE);
  Map_Put(stage->map, Man_GetX(stage->man)  ,Man_GetY(stage->man)-1, MAP_NONE);
  Map_Put(stage->map, Man_GetX(stage->man)+1,Man_GetY(stage->man)  , MAP_NONE);
  Map_Put(stage->map, Man_GetX(stage->man)  ,Man_GetY(stage->man)+1, MAP_NONE);

  /* ��󥹥����ο������ */
  stage->monsters_number = stage->number / 2 + 5;
  if ((stage->number % 2) == 1) stage->monsters_number *= 2;
  if (stage->monsters_number > MONSTERS_NUMBER_MAX)
    stage->monsters_number = MONSTERS_NUMBER_MAX;

  /* ��󥹥��������� */
  for (i = 0; i < stage->monsters_number; i++) {
    /* ��󥹥����ΰ�ư��®������� */
    speed = getrand(stage->number * 20) + stage->number * 10;
    if ((stage->number % 2) == 0) speed = (speed / 3 + 1) * 4;
    if (speed < 1) speed = 1;
    if (speed > 300) speed = 300;

    while (1) {
      x = getrand(stage->width);
      y = getrand(stage->height);

      if ( (x >= Man_GetX(stage->man) - 5) &&
	   (x <= Man_GetX(stage->man) + 5) &&
	   (y >= Man_GetY(stage->man) - 5) &&
	   (y <= Man_GetY(stage->man) + 5) )
	continue;

      if (Map_IsAbleToMove(stage->map, x, y)) break;
    }

    stage->monsters[i] = Monster_Create(&stage->_monsters[i],
					stage->disp, stage->map,
					x, y, getrand(4), getrand(4), speed);
    if (stage->monsters[i] == NULL) return (NULL);
  }

  return (stage);
}

Stage Stage_Destroy(Stage stage)
{
  int i;

  stage->map = Map_Destroy(stage->map);
  stage->man = Man_Destroy(stage->man);

  /* ��󥹥����κ�� */
  for (i = 0; i < stage->monsters_number; i++) {
    stage->monsters[i] = Monster_Destroy(&stage->_monsters[i]);
  }

  return (stage);
}

int Stage_Start(Stage stage)
{
  int i;
  int button_status;

  /* ���ơ����Υᥤ��롼�� */
  while (1) {

    /* �ܥ���β������֤μ��� */
    button_status = Disp_GetButtonStatus(stage->disp);

    if (button_status & DISP_BUTTON_START) return (STAGE_EXIT);

    /* �ͷ� */
    if (button_status & DISP_BUTTON_A)
      Man_Shoot(stage->man, stage->map,
		stage->monsters_number, stage->monsters);

    /* �ץ쥤�䡼�ΰ�ư */
    if (button_status & DISP_BUTTON_UP   )
      Man_Move(stage->man, stage->map, MAN_UP);
    if (button_status & DISP_BUTTON_DOWN ) 
      Man_Move(stage->man, stage->map, MAN_DOWN);
    if (button_status & DISP_BUTTON_LEFT ) 
      Man_Move(stage->man, stage->map, MAN_LEFT);
    if (button_status & DISP_BUTTON_RIGHT)
      Man_Move(stage->man, stage->map, MAN_RIGHT);

    /* ��󥹥����ΰ�ư */
    for (i = 0; i < stage->monsters_number; i++)
      Monster_Move(stage->monsters[i], stage->map, stage->man);

    /* ������ɽ�� */
    Disp_PrintScore(stage->disp, 10000,
		    Player_GetScore(Man_GetPlayer(stage->man)));

    /* ��󥹥�������ޤä����ɤ�����Ƚ�� */
    for (i = 0; i < stage->monsters_number; i++) {
      if ((Man_GetX(stage->man) == Monster_GetX(stage->monsters[i])) &&
	  (Man_GetY(stage->man) == Monster_GetY(stage->monsters[i])) ) {
	sys_wait(75 * 2); /* 1/75��ñ�� */
	return (STAGE_FAILED);
      }
    }

    /* ���ơ������ꥢ */
    if (Player_GetScore(Man_GetPlayer(stage->man)) >= stage->number * 100)
      break;
  }
  return (STAGE_SUCCEED);
}

/*****************************************************************************/
/* End of File.                                                              */
/*****************************************************************************/
