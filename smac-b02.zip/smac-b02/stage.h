#ifndef _Stage_h_INCLUDED_
#define _Stage_h_INCLUDED_

typedef struct _Stage * Stage;

#include "dsp.h"
#include "player.h"

#define STAGE_FAILED  0
#define STAGE_SUCCEED 1
#define STAGE_EXIT    2

Stage Stage_Create(Stage stage, Disp disp, int width, int height,
		   int stage_number, Player player);
int Stage_Start(Stage stage);
Stage Stage_Destroy(Stage stage);

#endif

/* End of File. */
