#ifndef _WWTERM_TERMLIB_H_
#define _WWTERM_TERMLIB_H_

int key_X1234_action(int key);
int key_Y1234_action(int key);
int key_A_action(int key);
int key_B_action(int key);
int key_START_action(int key);

#endif /* _WWTERM_TERMLIB_H_ */

/* End of Program  */
